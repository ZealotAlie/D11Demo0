#include "D11NormalMap.h"
#include "NormalMapEffect.h"

D11NormalMap::D11NormalMap(HINSTANCE hInstance)
	:D3DApp(hInstance)
	,mRotateCameraController(*this,10,800)
{
	mMainWndCaption = L"Direct 11 NormalMap App";
	mRenderOptions = Lighting;
	SetCameraControll(&mRotateCameraController);
}
D11NormalMap::~D11NormalMap()
{

}

bool D11NormalMap::Init()
{
	if(!D3DApp::Init())
	{
		return false;
	}

	AddUnknownInstance( new NormalMapEffect(md3dDevice,L"FX/NormalMap.fx"));

	return true;
}

void D11NormalMap::UpdateScene(float dt)
{
	D3DApp::UpdateScene(dt);
}

void D11NormalMap::DrawScene()
{
	ID3D11RenderTargetView* renderTargets[1] = { mRenderTargetView };
	md3dImmediateContext->OMSetRenderTargets( 1, renderTargets, mDepthStencilView );

	md3dImmediateContext->ClearRenderTargetView(mRenderTargetView,reinterpret_cast<const float*>(&Colors::LightSteelBlue));
	md3dImmediateContext->ClearDepthStencilView(mDepthStencilView,D3D11_CLEAR_DEPTH|D3D11_CLEAR_STENCIL,1.0f,0);


	HR(mSwapChain->Present(0, 0));
}