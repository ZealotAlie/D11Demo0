#ifndef _INSTANCINGDEMOAPP_H_
#define _INSTANCINGDEMOAPP_H_

#include "d3dApp.h"
#include "Effect.h"

class RenderObject;
class D11NormalMap:public D3DApp
{
public:
	D11NormalMap( HINSTANCE hInstance );
	~D11NormalMap();

	bool			Init()override;

	void			UpdateScene( float dt )override;
	void			DrawScene()override;

private:
	CommonEnvironment		mEnvironment;
	CameraCtrlRotate		mRotateCameraController;
};

#endif // ~_INSTANCINGDEMOAPP_H_